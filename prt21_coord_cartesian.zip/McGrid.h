// Interface for the CMcGrid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCGRID_H_
#define _MCGRID_H_

class CMcGrid
{
public:
	struct VtxD
	{
		D3DXVECTOR3	p;
		DWORD		d;

		VtxD(): p(0,0,0), d(0xFFFFFFFF){}
		VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0XFFFFFFFF): p(X,Y,Z), d(D){}

		enum {	FVF =(D3DFVF_XYZ|D3DFVF_DIFFUSE), };
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;
	
	INT			m_iN;							// Number of Grid for x and z
	FLOAT		m_fW;							// Interval width Grid
	VtxD*		m_pLine;

public:
	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();
	INT		FrameMove();
	void	Render();
	
public:
	CMcGrid();
	virtual ~CMcGrid();
};

#endif

