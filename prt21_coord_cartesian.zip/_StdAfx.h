//
//
////////////////////////////////////////////////////////////////////////////////


#pragma once


#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
#pragma warning( disable : 4996)


#define STRICT
#define _WIN32_WINNT			0x0400
#define _WIN32_WINDOWS			0x0400
#define DIRECTINPUT_VERSION		0x0800


#pragma comment(lib, "shell32.lib"		)
#pragma comment(lib, "comctl32.lib"		)



#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <DxErr.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"
#include "resource.h"


#include "McInput.h"
#include "McCam.h"
#include "McGrid.h"



#include "McParticle.h"

#include "Main.h"

#endif



