// Implementation of the CMcParticle class.
//
////////////////////////////////////////////////////////////////////////////////
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

#include <Windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "McParticle.h"


inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }

// Texture Load
INT	McUtil_TextureLoad(	LPDIRECT3DDEVICE9	pDev
					,	LPDIRECT3DTEXTURE9& texture
					,	TCHAR* sFileName
					,	DWORD _color=0xffffffff
					,	D3DXIMAGE_INFO *pSrcInfo=NULL
					,	DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
					,	DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
					,	D3DFORMAT d3dFormat = D3DFMT_UNKNOWN
					   )
{
	if ( FAILED(D3DXCreateTextureFromFileEx(
		pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat	//, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)) )
	{
		texture = NULL;
		return -1;
	}
	
	return 1;
}

CMcParticle::CMcParticle()
{
	m_pDev		= NULL;

	m_PrtN		= 0;
	m_PrtD		= NULL;

	m_fTimeAvg	= 0;
	m_bAni		= FALSE;
	
	m_pVtx		= NULL;
	m_pTx		= NULL;
}

CMcParticle::~CMcParticle()
{
	Destroy();
}


INT CMcParticle::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	m_PrtN	= 500;
	m_PrtD	= new CMcParticle::Tpart[m_PrtN];
	

	// ������ � ��¿� ����
	m_iVtx	= m_PrtN * 2 * 3;
	m_pVtx	= new VtxDUV1[ m_iVtx ];
	

	McUtil_TextureLoad(m_pDev, m_pTx, "Texture/alpha.png", 0x00FFFFFF);


	return 0;
}


void CMcParticle::Destroy()
{
	SAFE_DELETE_ARRAY(	m_PrtD	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_RELEASE(		m_pTx	);
}

INT CMcParticle::FrameMove()
{
	if(!m_bAni)
		return 0;

	int		i;

	// 1. ��� �����Ѵ�.
	FLOAT	ftime = m_fTimeAvg * 0.1f;


	for(i=0; i<m_PrtN; ++i)
	{
		CMcParticle::Tpart* pPrt = &m_PrtD[i];


		// ���������� ���Ѵ�.
		D3DXVECTOR3	vcAirR = pPrt->m_CrnV;					// ���������� ���� ����
		FLOAT		fLenV  = D3DXVec3LengthSq(&vcAirR);		// �ӵ��� ����(Vx*Vx + Vy*Vy + Vz*Vz)ũ�� ����

		// ���������� ���� ���͸� ���Ѵ�.
		D3DXVec3Normalize(&vcAirR, &vcAirR);

		// �̵� �ӵ��� �ݴ�� ����
		vcAirR	*= -1.F;

		// �ӷ����� * ���� ���� ����� ����.
		vcAirR	*= fLenV * pPrt->m_fDamp;


		// 1. ���ӵ��� ���������� ���Ѵ�.
		pPrt->m_CrnA = pPrt->m_IntA + vcAirR;

		// 2. ���� �ӵ� ����
		pPrt->m_CrnV += pPrt->m_CrnA * ftime;

		// 3. ���� ��ġ ����
		pPrt->m_CrnP += pPrt->m_CrnV * ftime;

		// 4. ��谪 ����. ����� ���� ���·� ����.
		if(pPrt->m_CrnP.y<0.f)
		{
			pPrt->m_bLive	= FALSE;
		}
	}


	// 2. ��ƼŬ�� ������ �����Ѵ�.
	for(i=0; i<m_PrtN; ++i)
	{
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		if(FALSE == pPrt->m_bLive)
			continue;

		D3DXCOLOR	xc = pPrt->m_dColor;

		pPrt->m_fLife -=pPrt->m_fFade*ftime;

		if(pPrt->m_fLife<=0.f)
		{
			pPrt->m_bLive	= FALSE;
			continue;
		}

		xc.a	= pPrt->m_fLife;
		pPrt->m_dColor	= xc;
	}
	

	// 3. ���� ��ƼŬ�� ����Ѵ�.
	for(i=0; i<m_PrtN; ++i)
	{
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		if(TRUE == pPrt->m_bLive)
			continue;

		this->SetPart(i);
	}





	// 4. ����� �����Ѵ�.

	// ī�޶��� ����
	D3DXMATRIX mtView;
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	D3DXVECTOR3 vcCamX(mtView._11, mtView._21, mtView._31);
	D3DXVECTOR3 vcCamY(mtView._12, mtView._22, mtView._32);
	D3DXVECTOR3 vcCamZ(mtView._13, mtView._23, mtView._33);

	for(i=0; i<m_PrtN; ++i)
	{	
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		D3DXVECTOR3	vcP	= pPrt->m_CrnP;

		// ī�޶��� Z��� ��ƼŬ�� ��ġ�� ����
		pPrt->m_PrsZ	= D3DXVec3Dot(&vcP, &vcCamZ);
	}

	// Sorting
	qsort (m_PrtD
			, m_PrtN
			, sizeof(CMcParticle::Tpart)
			, (int(*) (const void *, const void *)) CMcParticle::SortFnc);


	for(i=0; i<m_PrtN; ++i)
	{	
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		D3DXVECTOR3	vcP	= pPrt->m_CrnP;
		D3DXCOLOR	xcC	= pPrt->m_dColor;

		FLOAT		fW = pPrt->m_PrsW;
		FLOAT		fH = pPrt->m_PrsH;
		FLOAT		fD = min(fW, fH);

		CMcParticle::VtxDUV1* pVtx = &m_pVtx[i*6 + 0];

		(pVtx+0)->p.x	= vcP.x - (vcCamX.x - vcCamY.x) * fW;
		(pVtx+0)->p.y	= vcP.y - (vcCamX.y - vcCamY.y) * fH;
		(pVtx+0)->p.z	= vcP.z - (vcCamX.z - vcCamY.z) * fD;
		(pVtx+0)->u		= 0;
		(pVtx+0)->v		= 0;
		(pVtx+0)->d		= xcC;

		(pVtx+1)->p.x	= vcP.x + (vcCamX.x + vcCamY.x) * fW;
		(pVtx+1)->p.y	= vcP.y + (vcCamX.y + vcCamY.y) * fH;
		(pVtx+1)->p.z	= vcP.z + (vcCamX.z + vcCamY.z) * fD;
		(pVtx+1)->u		= 1;
		(pVtx+1)->v		= 0;
		(pVtx+1)->d		= xcC;

		(pVtx+2)->p.x	= vcP.x - (vcCamX.x + vcCamY.x) * fW;
		(pVtx+2)->p.y	= vcP.y - (vcCamX.y + vcCamY.y) * fH;
		(pVtx+2)->p.z	= vcP.z - (vcCamX.z + vcCamY.z) * fD;
		(pVtx+2)->u		= 0;
		(pVtx+2)->v		= 1;
		(pVtx+2)->d		= xcC;

		(pVtx+3)->p.x	= vcP.x + (vcCamX.x - vcCamY.x) * fW;
		(pVtx+3)->p.y	= vcP.y + (vcCamX.y - vcCamY.y) * fH;
		(pVtx+3)->p.z	= vcP.z + (vcCamX.z - vcCamY.z) * fD;
		(pVtx+3)->u		= 1;
		(pVtx+3)->v		= 1;
		(pVtx+3)->d		= xcC;

		m_pVtx[i*6 + 4] = m_pVtx[i*6 + 2];
		m_pVtx[i*6 + 5] = m_pVtx[i*6 + 1];
	}


	return 0;
}

void CMcParticle::Render()
{
	if(!m_bAni)
		return;

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);	

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetFVF(VtxDUV1::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_PrtN * 2, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}


void CMcParticle::SetAni(BOOL bAni)
{
	m_bAni = bAni;

	if(!m_bAni)
		return;

	for(int i=0; i<m_PrtN; ++i)
	{
		SetPart(i);
	}
}


void CMcParticle::SetAvgTime(FLOAT fTime)
{
	m_fTimeAvg = fTime;
}





void CMcParticle::SetPart(int nIdx)
{
	CMcParticle::Tpart* pPrt = &m_PrtD[nIdx];

	FLOAT	fTheta;		// ���� ��
	FLOAT	fPhi;		// ���� ��
	FLOAT	fSpdR;		// �ӵ� ũ��

	// �ʱ� ���ӵ�
	pPrt->m_IntA = D3DXVECTOR3(0, -0.2F,0);

	//�ʱ� �ӵ��� ��ġ�� �����ϱ� ���� ����
	fTheta	= float(rand()%61);
	fTheta	-=30.f;
	
	fPhi	= float(rand()%360);

	fSpdR = 100.f + rand()%101;
	fSpdR *=0.14f;

	// �������� ����
	fTheta	= D3DXToRadian(fTheta);
	fPhi	= D3DXToRadian(fPhi);

	// �ʱ� �ӵ�
	pPrt->m_IntV.x = fSpdR * sinf(fTheta) * sinf(fPhi);
	pPrt->m_IntV.y = fSpdR * cosf(fTheta);
	pPrt->m_IntV.z = fSpdR * sinf(fTheta) * cosf(fPhi);

	// �ʱ� ��ġ		
	pPrt->m_IntP.x = 0.f;
	pPrt->m_IntP.y = 0.f;
	pPrt->m_IntP.z = 0.f;


	// ź�� ��� ����
	pPrt->m_fElst= (50 + rand()%51)*0.01f;

	// �������� ���
	pPrt->m_fDamp= (100 + rand()%101)*0.00001F;

	// �ʱ� ��ġ, �ӵ�, ���ӵ��� ������ ������ �ʱ� ������ ����
	pPrt->m_CrnP = pPrt->m_IntP;
	pPrt->m_CrnV = pPrt->m_IntV;
	pPrt->m_CrnA = pPrt->m_IntA;



	// ������ ���� ���
	pPrt->m_bLive	= TRUE;
	pPrt->m_fLife	= 30.f + rand()%71;
	pPrt->m_fLife	= 30.f + rand()%71;
	pPrt->m_fLife	*=0.01f;

	pPrt->m_fFade	=( 100 + rand()%101  ) *0.0001f;
	pPrt->m_dColor	=	D3DXCOLOR(1, 1, 1, pPrt->m_fLife);


	// ������ ǥ�� ���
	pPrt->m_PrsW = 50.f + rand()%101;
	pPrt->m_PrsW *= 0.02f;

	pPrt->m_PrsH = 50.f + rand()%101;
	pPrt->m_PrsH *= 0.06f;
}


