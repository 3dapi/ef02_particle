// Implementation of the CMcGrid class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcGrid::CMcGrid()
{
	m_pDev	= NULL;
	
	m_iN	= 0;
	m_fW	= 0;

	m_pLine	= NULL;
}

CMcGrid::~CMcGrid()
{
	Destroy();	
}



INT CMcGrid::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	int		i, j;
	FLOAT	fMax =10000.f;

	INT		iN	= 20;

	m_iN	= 6  + iN * 4 ;
	m_fW	= 10.f;

	m_pLine = new CMcGrid::VtxD[ m_iN * 2];

	m_pLine[ 0] = CMcGrid::VtxD(-fMax,     0,     0, 0xFF770000);
	m_pLine[ 1] = CMcGrid::VtxD(    0,     0,     0, 0xFF770000);
	m_pLine[ 2] = CMcGrid::VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = CMcGrid::VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = CMcGrid::VtxD(    0, -fMax,     0, 0xFF007700);
	m_pLine[ 5] = CMcGrid::VtxD(    0,     0,     0, 0xFF007700);
	m_pLine[ 6] = CMcGrid::VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = CMcGrid::VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = CMcGrid::VtxD(    0,     0, -fMax, 0xFF000077);
	m_pLine[ 9] = CMcGrid::VtxD(    0,     0,     0, 0xFF000077);
	m_pLine[10] = CMcGrid::VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = CMcGrid::VtxD(    0,     0,  fMax, 0xFF0000FF);

	j =6 * 2;

	for(i=0; i<iN; ++i)
	{
		m_pLine[j + 4*i +0 ] = CMcGrid::VtxD(-m_fW * iN, 1.f,  m_fW* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 4*i +1 ] = CMcGrid::VtxD( m_fW * iN, 1.f,  m_fW* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 4*i +2 ] = CMcGrid::VtxD(-m_fW * iN, 1.f, -m_fW* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 4*i +3 ] = CMcGrid::VtxD( m_fW * iN, 1.f, -m_fW* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
	}

	j += i*4;

	for(i=0; i<iN; ++i)
	{

		m_pLine[j + 4*i +0 ] = CMcGrid::VtxD( m_fW* (i+1), 1.f,-m_fW * iN, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 4*i +1 ] = CMcGrid::VtxD( m_fW* (i+1), 1.f, m_fW * iN, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 4*i +2 ] = CMcGrid::VtxD(-m_fW* (i+1), 1.f,-m_fW * iN, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 4*i +3 ] = CMcGrid::VtxD(-m_fW* (i+1), 1.f, m_fW * iN, (i%2)? 0xFF999999 : 0xFF666666);
	}

	return 0;
}

void CMcGrid::Destroy()
{
	SAFE_DELETE(	m_pLine	);
}


INT CMcGrid::FrameMove()
{
	return 0;
}

void CMcGrid::Render()
{
	// Render Lines
	DWORD dMnLgt;
	DWORD dMnFog;

	DWORD dMnAblend;
	DWORD dMnAtest;

	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);
	m_pDev->GetRenderState( D3DRS_FOGENABLE, &dMnFog);
	m_pDev->GetRenderState( D3DRS_ALPHABLENDENABLE,  &dMnAblend);
	m_pDev->GetRenderState( D3DRS_ALPHATESTENABLE,  &dMnAtest);

	m_pDev->SetRenderState( D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER , D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER , D3DTEXF_LINEAR);

	
	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(CMcGrid::VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, m_iN, m_pLine, sizeof(CMcGrid::VtxD));

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
	m_pDev->SetRenderState( D3DRS_FOGENABLE, dMnFog);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, dMnAblend);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, dMnAtest);
}