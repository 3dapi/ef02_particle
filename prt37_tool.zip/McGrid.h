// Interface for the CMcGrid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCGRID_H_
#define _MCGRID_H_

class CMcGrid
{
protected:
	VtxD*		m_pLine;
	
public:
	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();
	
public:
	CMcGrid();
	~CMcGrid();
};

#endif