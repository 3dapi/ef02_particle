///////////////////////////////////////////////////////////////////////////////
// 
// Explain: Base type Created by Heesung Oh
// Date   : 2003-04-14
// Update : 2004-08-14
// History: 


#ifndef _MCBASETYPE_H_
#define _MCBASETYPE_H_


// about DX
typedef FLOAT												VEC1;
typedef D3DXVECTOR2											VEC2;
typedef	D3DXVECTOR3											VEC3;
typedef D3DXVECTOR4											VEC4;
typedef D3DXMATRIX											MATA;
typedef D3DXQUATERNION										QUAT;
typedef D3DXCOLOR											XCLR;

typedef	LPDIRECT3D9											PD3D;
typedef LPDIRECT3DDEVICE9									PDEV;
typedef	LPD3DXSPRITE										PDSP;

typedef D3DMATERIAL9										XMTL;
typedef LPDIRECT3DTEXTURE9									PDTX;
typedef	D3DXIMAGE_INFO										XIMG;
typedef LPDIRECT3DCUBETEXTURE9								PDCB;
typedef LPDIRECT3DVOLUMETEXTURE9							PDVT;
typedef ID3DXRenderToEnvMap*								PDRE;
typedef ID3DXEffect*										PDEF;

typedef LPDIRECT3DSURFACE9									PDSF;
typedef LPD3DXRENDERTOSURFACE								PDRS;
typedef	LPDIRECT3DSWAPCHAIN9								PDSW;				//	Swap chain

typedef LPDIRECT3DVERTEXBUFFER9								PDVB;
typedef LPDIRECT3DSTATEBLOCK9								PDBL;
typedef LPDIRECT3DINDEXBUFFER9								PDIB;

//typedef LPDIRECTSOUND3DBUFFER								PDSD;
//typedef LPDIRECTSOUND3DLISTENER							PDSL;

typedef LPDIRECT3DVERTEXSHADER9								PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9						PDVD;
typedef	LPD3DXEFFECT										PDEF;


typedef vector<VEC2>										lsVEC2;
typedef lsVEC2::iterator									itVEC2;

typedef vector<VEC3>										lsVEC3;
typedef lsVEC3::iterator									itVEC3;

typedef vector<VEC4>										lsVEC4;
typedef lsVEC4::iterator									itVEC4;

// about STL
typedef vector<INT>											lsINT;
typedef lsINT::iterator										itINT;

typedef vector<FLOAT>										lsFLOAT;
typedef lsFLOAT::iterator									itFLOAT;

typedef vector<WORD>										lsWORD;
typedef lsWORD::iterator									itWORD;

typedef vector<DWORD>										lsDWORD;
typedef lsDWORD::iterator									itDWORD;

typedef vector<RECT>										lsRect;
typedef lsRect::iterator									itRect;

#endif _MCBASETYPE_H_