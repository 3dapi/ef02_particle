// McScene.cpp: implementation of the CMcScene class.
//
//////////////////////////////////////////////////////////////////////


#include "StdAfx.h"


CMcScene::CMcScene()
{
	m_pTxCsr	= NULL;
	m_pEft		= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();	
}



INT		CMcScene::Init()
{
	McUtil_TextureLoad("Texture/cursor.png", m_pTxCsr, 0x00FFFFFF, NULL, D3DX_FILTER_NONE);

	SAFE_NEWINIT(	m_pEft, CEftPetal		);
	
	return 1;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTxCsr	);
	SAFE_DELETE(	m_pEft		);
}

INT CMcScene::FrameMove()
{
	KEY_DOWN(DIK_R)
	{
		m_pEft->Reset();
	}
	

	SAFE_FRMOV(	m_pEft	);
	return 1;
}

void	CMcScene::Render()
{
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE,FALSE);
	GDEVICE->SetRenderState(D3DRS_ZENABLE, FALSE);


	SAFE_RENDER(	m_pEft	);

	

	RECT	rt2 = {0,0,16, 25};
	VEC2	vcMouse = GINPUT->GetMousePos2();

	GSPRITE->Begin(D3DXSPRITE_ALPHABLEND);
	GSPRITE->Draw(m_pTxCsr, &rt2, NULL, (D3DXVECTOR3*)&vcMouse, D3DXCOLOR(1,1,1,1));

	GSPRITE->End();

	GDEVICE->SetRenderState(D3DRS_ZENABLE, TRUE);
}
