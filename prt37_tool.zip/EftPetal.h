// EftPetal.h: interface for the CEftPetal class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _EFTPETAL_H_
#define _EFTPETAL_H_


struct EftPt																// Particle structure
{
	INT		Id;
	VEC3	p;																	// Position
	VEC3	v;																	// Velocity
	VEC3	a;																	// X acceleration

	VEC3	r ;																	// rotation Euler Angle 
	VEC3	rV;																	// rotation Euler Angle Velocity

	VEC4	s;																	// scale 
	XCLR	c;																	// Color
	XCLR	cV;																	// Color Velocity

	FLOAT	w;																	// depth

	bool	bLive;																// Active (Yes/No)
	FLOAT	fLife;																// Particle fLife
	FLOAT	fFade;																// Fade Speed
	
	FLOAT	fW;																	// Width
	FLOAT	fH;																	// Height
	FLOAT	fFlp;																// Flapping Triangle
	FLOAT	fDir;																// Flap Direction (Increase Value)

	FLOAT	fZ;
	
	
	EftPt()
	{
		Id= 0;
		p.x=0.f;	p.y=0.f;	p.z=0.f;
		v.x=0.f;	v.y=0.f;	v.z=0.f;
		a.x=0.f;	a.y=0.f;	a.z=0.f;
		c.r =1.f;	c.g =1.f;	c.b = 1.f;	c.a= 1.f;
		
		bLive= true;
		fLife=1.f;
		fFade=0.f;
		fW=0.5f;
		fH=0.1f;

		w = 0.f;
	}

};

class CEftPetal
{
protected:
	bool		m_bRn;
	VEC3		m_vecP;
	INT			m_iN;
	VtxDUV1*	m_pVtx;
	EftPt*		m_pPrt;
	
	PDTX		m_pTx;

	EftPt		m_Param;

	XCLR		m_xClr;
	VEC3		m_vcWind;
	FLOAT		m_fWindL;
	VEC3		m_vcPrtb;

	INT			m_bBill;
	
public:
	
	CEftPetal();
	~CEftPetal();
	
	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
	void	Reset();

protected:
	void	Set(INT i);

public:
	static int SortFnc (EftPt* p1, const EftPt* p2)
	{
		INT	score1, score2;

		score1 = p1->fZ;
		score2 = p2->fZ;

		if(score1 < score2)
			return 1;

		else if(score1 == score2)
			return 0;

		else 
			return -1;
	}

	void SetParam_Num		(int	iV);
	void SetParam_P_X		(float	fV);
	void SetParam_P_Y		(float	fV);
	void SetParam_P_Z		(float	fV);
	void SetParam_V_X		(float	fV);
	void SetParam_V_Y		(float	fV);
	void SetParam_V_Z		(float	fV);
	void SetParam_R_X		(float	fV);
	void SetParam_R_Y		(float	fV);
	void SetParam_R_Z		(float	fV);
	void SetParam_RV_X		(float	fV);
	void SetParam_RV_Y		(float	fV);
	void SetParam_RV_Z		(float	fV);
	void SetParam_S_X		(float	fV);
	void SetParam_S_Y		(float	fV);
	void SetParam_S_Z		(float	fV);
	void SetParam_XCLR_R	(float	fV);
	void SetParam_XCLR_G	(float	fV);
	void SetParam_XCLR_B	(float	fV);
	void SetParam_XCLR_A	(float	fV);
	void SetParam_XCLR_C_R	(float	fV);
	void SetParam_XCLR_C_G	(float	fV);
	void SetParam_XCLR_C_B	(float	fV);
	void SetParam_XCLR_C_A	(float	fV);
	void SetParam_WND_X		(float	fV);
	void SetParam_WND_Y		(float	fV);
	void SetParam_WND_Z		(float	fV);
	void SetParam_WND_Length(float	fV);
	void SetParam_PRT_X		(float	fV);
	void SetParam_PRT_Y		(float	fV);
	void SetParam_PRT_Z		(float	fV);

	void SetParam_Bill		(int	iV);
};

#endif
