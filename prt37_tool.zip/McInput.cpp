// Implementation of the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////


#include "StdAfx.h"


CMcInput::CMcInput()
{
	m_pDInput	= NULL;
	m_pDiKey	= NULL;
	m_pDiMs		= NULL;
}

CMcInput::~CMcInput()
{
	SAFE_RELEASE(	m_pDiKey	);
	SAFE_RELEASE(	m_pDiMs		);
	SAFE_RELEASE(	m_pDInput	);
}


INT CMcInput::Init()
{
	memset(KeyCur, 0, sizeof(KeyCur));
	memset(KeyOld, 0, sizeof(KeyOld));

	memset(&vcMsCur, 0, sizeof(vcMsCur));
	memset(&vcMsOld, 0, sizeof(vcMsOld));
	memset(&MsStCur, 0, sizeof(MsStCur));
	memset(&MsStOld, 0, sizeof(MsStOld));

	if(FAILED(InitDInput()))
		return -1;

	return 1;
}

INT CMcInput::FrameMove()
{
	vcDelta = vcMsCur - vcMsOld;

	memcpy(KeyOld		, KeyCur	, sizeof(KeyCur		));
	memcpy(&vcMsOld		, &vcMsCur	, sizeof(vcMsCur	));
	memcpy(&MsStOld		, &MsStCur	, sizeof(MsStCur	));

	memset(&MsStCur, 0  , sizeof(MsStCur));

	UpdateDInput();

	return 1;
}





bool CMcInput::GetKey(BYTE cKey)
{
	return (KeyCur[cKey] & 0x80 && KeyOld[cKey] != KeyCur[cKey]);
}

bool CMcInput::KeyState(BYTE cKey)
{
	return (KeyCur[cKey] & 0x80 && true);
}

bool CMcInput::GetMouseSt(INT nM)
{
	return MsStOld.rgbButtons[nM]? true: false;
}

VEC3 CMcInput::GetMousePos()
{
	return vcMsCur;
}

VEC2 CMcInput::GetMousePos2()
{
	return VEC2(vcMsCur.x, vcMsCur.y);
}


bool CMcInput::ButtonDn(INT nM)
{
	return ( MsStOld.rgbButtons[nM] == 0 && MsStCur.rgbButtons[nM] != 0)? true: false;
}

bool CMcInput::ButtonUp(INT nM)
{
	return ( MsStOld.rgbButtons[nM] != 0 && MsStCur.rgbButtons[nM] == 0)? true: false;
}

bool CMcInput::ButtonSt(INT nM)
{
	return ( MsStOld.rgbButtons[nM] != 0 && MsStCur.rgbButtons[nM] != 0)? true: false;
}

bool CMcInput::ButtonPrss(INT nM)
{
	return ( MsStOld.rgbButtons[nM] != 0 && MsStCur.rgbButtons[nM] != 0)? true: false;
}


VEC3 CMcInput::GetMouseDelta()
{
	return vcDelta;
}

INT CMcInput::InitDInput()
{
	DWORD		flags = DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY;

	// Mouse
	HINSTANCE hInst = (HINSTANCE)GetModuleHandle(NULL);
	
	if (FAILED(DirectInput8Create(	hInst,	DIRECTINPUT_VERSION,	IID_IDirectInput8,	(void **)&m_pDInput,	NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
		return -1;
	
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
		return -1;
	
	if (FAILED(m_pDiKey->SetCooperativeLevel(GHWND, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
		return -1;

	
	// Keyboard
	if (FAILED(DirectInput8Create(	hInst,	DIRECTINPUT_VERSION,	IID_IDirectInput8,	(void **)&m_pDInput,	NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMs, NULL)))
		return -1;
	
	if (FAILED(m_pDiMs->SetDataFormat(&c_dfDIMouse)))
		return -1;
	
	if (FAILED(m_pDiMs->SetCooperativeLevel(GHWND, flags)))
		return -1;

	
	
	
	return 1;
}


INT CMcInput::UpdateDInput()
{
	// Keyboard
	if (FAILED(m_pDiKey->GetDeviceState(sizeof(KeyCur), (LPVOID)KeyCur)))
	{
		memset(KeyCur, 0, sizeof(KeyCur));
		
		if (FAILED(m_pDiKey->Acquire()))
			return 1;
		
		if (FAILED(m_pDiKey->GetDeviceState(sizeof(KeyCur), (LPVOID)KeyCur)))
			return 1;
	}



	// Mouse
	if (FAILED(m_pDiMs->GetDeviceState(sizeof(DIMOUSESTATE), &MsStCur)))
	{
		if (FAILED(m_pDiMs->Acquire()))
			return 1;
		
		if (FAILED(m_pDiMs->GetDeviceState(sizeof(DIMOUSESTATE), &MsStCur)))
			return 1;
	}

	POINT	MsPos;
	GetCursorPos(&MsPos);
	GFORM->SetCursorPosition(&MsPos);
	GDEVICE->SetCursorPosition( MsPos.x, MsPos.y, 0 );

	vcMsCur.x = FLOAT(MsPos.x);
	vcMsCur.y = FLOAT(MsPos.y);

	vcMsCur.z += FLOAT(MsStCur.lZ);
	
	return 1;
}