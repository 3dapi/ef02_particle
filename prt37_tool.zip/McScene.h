// Interface for the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

class CMcScene
{
public:
	PDTX		m_pTxCsr;														// Cursor
	CEftPetal*	m_pEft;															// Effect instance

public:
	CMcScene();
	~CMcScene();
	
	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif
