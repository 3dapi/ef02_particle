//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DxMFC.rc
//
#define IDR_MAINFRAME                   101
#define IDI_MAIN_ICON                   101
#define IDD_FORMVIEW                    102
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_SELECTDEVICE                144
#define IDC_DEVICE_COMBO                1000
#define IDC_ADAPTER_COMBO               1002
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RESOLUTION_COMBO            1004
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_MULTISAMPLE_QUALITY_COMBO   1011
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDC_RENDERVIEW                  2002
#define IDC_VIEWFULLSCREEN              2003
#define IDC_CHANGEDEVICE                2004
#define IDC_PARMA_NUM                   2005
#define IDC_PARAM_P_X                   2006
#define IDC_PARAM_P_Y                   2007
#define IDC_PARAM_P_Z                   2008
#define IDC_BILLBOARD                   2011
#define IDC_PARAM_V_X                   2022
#define IDC_PARAM_V_Y                   2023
#define IDC_PARAM_V_Z                   2024
#define IDC_PARAM_R_X                   2025
#define IDC_PARAM_R_Y                   2026
#define IDC_PARAM_R_Z                   2027
#define IDC_PARAM_RV_X                  2028
#define IDC_PARAM_RV_Y                  2029
#define IDC_PARAM_RV_Z                  2030
#define IDC_PARAM_S_X                   2031
#define IDC_PARAM_S_Y                   2032
#define IDC_PARAM_S_Z                   2033
#define IDC_PARAM_XCLR_R                2034
#define IDC_PARAM_XCLR_G                2035
#define IDC_PARAM_XCLR_B                2036
#define IDC_PARAM_XCLR_A                2037
#define IDC_PARAM_XCLR_C_R              2038
#define IDC_PARAM_XCLR_C_G              2039
#define IDC_PARAM_XCLR_C_B              2040
#define IDC_PARAM_XCLR_C_A              2041
#define IDC_PARAM_WND_X                 2042
#define IDC_PARAM_WND_Y                 2043
#define IDC_PARAM_WND_Z                 2044
#define IDC_PARAM_WND_LENGTH            2045
#define IDC_PARAM_PRT_X                 2046
#define IDC_PARAM_PRT_Y                 2047
#define IDC_PARAM_PRT_Z                 2048
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_EXIT                        40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         2012
#define _APS_NEXT_SYMED_VALUE           300
#endif
#endif
