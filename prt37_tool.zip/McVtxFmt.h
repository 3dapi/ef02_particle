#ifndef _MCVTXFORMAT_H_
#define _MCVTXFORMAT_H_

typedef struct tagUV2
{
	FLOAT	u0,v0;

	tagUV2(){}
	tagUV2(FLOAT U0,FLOAT V0)		{	u0=U0;v0=V0;}
}UV2;





struct VtxIdx
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	VtxIdx()							{	a = 0;		 b = 1;		 c = 2;		}
	VtxIdx(WORD A, WORD B, WORD C)		{	a = A;		 b = B;		 c = C;		}
	VtxIdx(WORD* R)						{	a = R[0];	 b = R[1];	 c = R[2];	}

	operator WORD* ()					{		return (WORD *) &a;				}
	operator CONST WORD* () const		{		return (CONST WORD *) &a;		}
};



struct VtxD
{
	VEC3	p;
	DWORD	d;
	
	VtxD()								{	p.x=p.y=p.z = 0.f;		d = 0xFFFFFFFF;		}
	VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D){	p.x = X;	p.y = Y;	p.z = Z;	d = D;	}

	enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
};



struct VtxDUV1
{
	VEC3	p;
	DWORD	d;
	FLOAT	u, v;
	
	VtxDUV1()							{	p.x=p.y=p.z=0.0f;	u=v=0.0f;		d=0xFFFFFFFF;			}
	VtxDUV1(FLOAT X, FLOAT Y, FLOAT Z
			, FLOAT U, FLOAT V
			, DWORD D=0xFFFFFFFF)		{	p.x=X; p.y=Y;p.z=Z;u=U;v=V;	d=D;							}

	enum {	FVF= (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)	};
	
};



struct VtxDUV2
{
    VEC3	p;
	DWORD	d;
	FLOAT	u1, v1;
	FLOAT	u2, v2;

	enum {	FVF= (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX2)	};
};


#endif