// Implementation of the CEftPetal class.
//
////////////////////////////////////////////////////////////////////////////////


#include "StdAfx.h"


CEftPetal::CEftPetal()
{
	m_vecP	= VEC3(0,0 ,0);
	
	m_iN	= 1024;
	m_pVtx	= NULL;
	m_pPrt	= NULL;
	
	m_bRn	= false;
	
	m_pTx	= NULL;
	
	
	m_Param.p.x		= 1000;
	m_Param.p.y		= 300;
	m_Param.p.z		= 1000;

	m_Param.v.x		= 5.f;
	m_Param.v.y		= 8.f;
	m_Param.v.z		= 5.f;

	m_Param.r.x		=360;
	m_Param.r.y		=360;
	m_Param.r.z		=360;

	m_Param.rV.x	=1.f;
	m_Param.rV.y	=1.f;
	m_Param.rV.z	=1.f;

	m_Param.s.x		= 3.f;
	m_Param.s.y		= 3.f;
	m_Param.s.z		= 3.f;
	
	m_xClr.r		= 1.1f;
	m_xClr.g		= 1.1f;
	m_xClr.b		= 1.1f;
	m_xClr.a		= 1.1f;

	m_Param.c.r		= 15.f;
	m_Param.c.g		= 15.f;
	m_Param.c.g		= 15.f;
	m_Param.c.a		= 15.f;

	m_Param.cV.r	= 1.f;
	m_Param.cV.g	= 1.f;
	m_Param.cV.g	= 1.f;
	m_Param.cV.a	= 1.f;

	m_fWindL		=.05f;
	m_vcWind.x		= 0.5f;
	m_vcWind.y		= 0.0f;
	m_vcWind.z		= 0.5f;
	
	m_vcPrtb.x		=  3.f;
	m_vcPrtb.y		=  3.f;
	m_vcPrtb.z		=  3.f;
	
	D3DXVec3Normalize(&m_vcWind, &m_vcWind);
}

CEftPetal::~CEftPetal()
{
	Destroy();
}

INT CEftPetal::Init()
{
	m_bRn = true;

	
	m_pPrt = (EftPt*) calloc(m_iN, sizeof(EftPt));
	m_pVtx = (VtxDUV1*) calloc(m_iN*6, sizeof(VtxDUV1));
	
	McUtil_TextureLoad("Texture/Petal.png", m_pTx, 0x00FFFFFF);
	
	GFORM->GetDlgItem(IDC_PARMA_NUM			)->SetWindowText(McUtil_Forming("%d",    m_iN			));
	GFORM->GetDlgItem(IDC_PARAM_P_X			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.p.x	));
	GFORM->GetDlgItem(IDC_PARAM_P_Y			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.p.y	));
	GFORM->GetDlgItem(IDC_PARAM_P_Z			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.p.z	));
	GFORM->GetDlgItem(IDC_PARAM_V_X			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.v.x	));
	GFORM->GetDlgItem(IDC_PARAM_V_Y			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.v.y	));
	GFORM->GetDlgItem(IDC_PARAM_V_Z			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.v.z	));
	GFORM->GetDlgItem(IDC_PARAM_R_X			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.r.x	));
	GFORM->GetDlgItem(IDC_PARAM_R_Y			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.r.y	));
	GFORM->GetDlgItem(IDC_PARAM_R_Z			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.r.z	));
	GFORM->GetDlgItem(IDC_PARAM_RV_X		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.rV.x	));
	GFORM->GetDlgItem(IDC_PARAM_RV_Y		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.rV.y	));
	GFORM->GetDlgItem(IDC_PARAM_RV_Z		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.rV.z	));
	GFORM->GetDlgItem(IDC_PARAM_S_X			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.s.x	));
	GFORM->GetDlgItem(IDC_PARAM_S_Y			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.s.y	));
	GFORM->GetDlgItem(IDC_PARAM_S_Z			)->SetWindowText(McUtil_Forming("%4.3f", m_Param.s.z	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_R		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.c.r	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_G		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.c.g	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_B		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.c.g	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_A		)->SetWindowText(McUtil_Forming("%4.3f", m_Param.c.a	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_C_R	)->SetWindowText(McUtil_Forming("%4.3f", m_Param.cV.r	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_C_G	)->SetWindowText(McUtil_Forming("%4.3f", m_Param.cV.g	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_C_B	)->SetWindowText(McUtil_Forming("%4.3f", m_Param.cV.g	));
	GFORM->GetDlgItem(IDC_PARAM_XCLR_C_A	)->SetWindowText(McUtil_Forming("%4.3f", m_Param.cV.a	));
	GFORM->GetDlgItem(IDC_PARAM_WND_X		)->SetWindowText(McUtil_Forming("%4.3f", m_fWindL		));
	GFORM->GetDlgItem(IDC_PARAM_WND_Y		)->SetWindowText(McUtil_Forming("%4.3f", m_vcWind.x		));
	GFORM->GetDlgItem(IDC_PARAM_WND_Z		)->SetWindowText(McUtil_Forming("%4.3f", m_vcWind.y		));
	GFORM->GetDlgItem(IDC_PARAM_WND_LENGTH	)->SetWindowText(McUtil_Forming("%4.3f", m_vcWind.z		));
	GFORM->GetDlgItem(IDC_PARAM_PRT_X		)->SetWindowText(McUtil_Forming("%4.3f", m_vcPrtb.x		));
	GFORM->GetDlgItem(IDC_PARAM_PRT_Y		)->SetWindowText(McUtil_Forming("%4.3f", m_vcPrtb.y		));
	GFORM->GetDlgItem(IDC_PARAM_PRT_Z		)->SetWindowText(McUtil_Forming("%4.3f", m_vcPrtb.z		));

	
	CButton* pBtn = (CButton*)GFORM->GetDlgItem(IDC_BILLBOARD);
	(pBtn)->SetCheck(m_bBill);

	
	
	return 1;
}



void CEftPetal::Destroy()
{
	SAFE_FREE(m_pPrt);
	SAFE_FREE(m_pVtx);
	
	SAFE_RELEASE(	m_pTx	);
}


void CEftPetal::Reset()
{
	m_bRn = true;
	
	for(int i=0;i<m_iN; ++i)
	{
		Set(i);
	}
}


void CEftPetal::Set(INT i)
{
	m_pPrt[i].bLive = true;
	
	m_pPrt[i].p.x= m_Param.p.x - rand()%int(m_Param.p.x *2 + 1);
	m_pPrt[i].p.y= rand()%int(m_Param.p.y) + 30;
	m_pPrt[i].p.z= m_Param.p.z - rand()%int(m_Param.p.z *2 + 1);
	
	m_pPrt[i].p += m_vecP;
	
	m_pPrt[i].v.x  = -m_Param.v.x + rand()%int(m_Param.v.x * 10.f+1) * m_Param.v.x * 0.01f;
	m_pPrt[i].v.y  = -m_Param.v.y;
	m_pPrt[i].v.z  = -m_Param.v.z + rand()%int(m_Param.v.z * 10.f+1) * m_Param.v.z * 0.01f;
	
	m_pPrt[i].v	*=0.1f;
	
	m_pPrt[i].r.x=rand()%int(m_Param.r.x+1);
	m_pPrt[i].r.y=rand()%int(m_Param.r.y+1);
	m_pPrt[i].r.z=rand()%int(m_Param.r.z+1);
	
	m_pPrt[i].rV.x=rand()%int(m_Param.rV.x+1)-m_Param.rV.x;
	m_pPrt[i].rV.y=rand()%int(m_Param.rV.y+1)-m_Param.rV.y;
	m_pPrt[i].rV.z=rand()%int(m_Param.rV.z+1)-m_Param.rV.z;
	
	m_pPrt[i].c.r = rand()%int(m_Param.c.r+1);
	m_pPrt[i].c.g = rand()%int(m_Param.c.g+1);
	m_pPrt[i].c.b = rand()%int(m_Param.c.b+1);
	m_pPrt[i].c.a = rand()%int(m_Param.c.a+1);

	m_pPrt[i].c.r /= m_Param.c.r;
	m_pPrt[i].c.g /= m_Param.c.g;
	m_pPrt[i].c.b /= m_Param.c.b;
	m_pPrt[i].c.a /= m_Param.c.a;

	m_pPrt[i].cV.r = rand()%int(m_Param.cV.r+1);
	m_pPrt[i].cV.g = rand()%int(m_Param.cV.g+1);
	m_pPrt[i].cV.b = rand()%int(m_Param.cV.b+1);
	m_pPrt[i].cV.a = rand()%int(m_Param.cV.a+1);

	m_pPrt[i].cV.r /= m_Param.cV.r;
	m_pPrt[i].cV.g /= m_Param.cV.g;
	m_pPrt[i].cV.b /= m_Param.cV.b;
	m_pPrt[i].cV.a /= m_Param.cV.a;

	m_pPrt[i].cV *=0.01f;


	m_pPrt[i].c +=m_xClr;

	
	
	m_pPrt[i].s.w= m_Param.s.x + m_Param.s.y *( rand()%int(m_Param.s.z +1));
}



INT CEftPetal::FrameMove()
{
	if(!m_bRn)
		return 0;
	
	INT i;
	
	MATA matX;
	MATA matY;
	MATA matZ;
	MATA matS;
	MATA matW;
	
	VEC3 vcWind;
	VEC3	vcPt;

	VEC3 vcCam	= GCAMERA->GetCamPos();
	VEC3	vcTmp;
	MATA	mtB =  GCAMERA->GetMatrixBll();
	VEC3	vcZ	= VEC3(mtB._31, mtB._32, mtB._33);

	
	for(i=0;i<m_iN; ++i)
	{	
		// �̵�
		
		// �ٶ��� perturbation�� ���Ѵ�.
		vcWind = m_fWindL * m_vcWind;
		
		vcPt.x = rand()%int(m_vcPrtb.x+1);
		vcPt.y = rand()%int(m_vcPrtb.x+1);
		vcPt.z = rand()%int(m_vcPrtb.x+1);
		
		vcPt.x *= (m_vcPrtb.x);
		vcPt.y *= (m_vcPrtb.y);
		vcPt.z *= (m_vcPrtb.z);
		
		vcPt *= 0.1f;
		
		vcWind.x += vcPt.x * (1+sinf(DEGtoRAD(m_pPrt[i].r.x)));
		vcWind.y += vcPt.y * (1+sinf(DEGtoRAD(m_pPrt[i].r.y)));
		vcWind.z += vcPt.z * (1+sinf(DEGtoRAD(m_pPrt[i].r.z)));
		
		
		
		//�ٶ��� ���Ѵ�.
		m_pPrt[i].p += m_pPrt[i].v + vcWind;

		if(m_pPrt[i].c.r <=0)	m_pPrt[i].c.r = 0;
		if(m_pPrt[i].c.g <=0)	m_pPrt[i].c.g = 0;
		if(m_pPrt[i].c.b <=0)	m_pPrt[i].c.b = 0;

		//Color
		m_pPrt[i].c -= m_pPrt[i].cV;
		
		if(	m_pPrt[i].p.y<=0 ||
			m_pPrt[i].p.y>300 || 
			m_pPrt[i].p.x>m_Param.p.x ||
			m_pPrt[i].p.z>m_Param.p.z ||
			m_pPrt[i].c.r <=0 ||
			m_pPrt[i].c.g <=0 ||
			m_pPrt[i].c.b <=0 ||
			m_pPrt[i].c.a <=0)
		{
			m_pPrt[i].bLive = false;
		}


		
		
		
		
		if(!m_pPrt[i].bLive)
		{
			Set(i);
		}


		vcTmp = m_pPrt[i].p - vcCam;
		m_pPrt[i].fZ = D3DXVec3Dot(&vcZ, &vcTmp);
	}


	qsort (m_pPrt, m_iN, sizeof(EftPt), (int(*) (const void *, const void *)) this->SortFnc);	
		
	for(i=0;i<m_iN; ++i)
	{	
		// ȸ��
		m_pPrt[i].r +=m_pPrt[i].rV;
		D3DXMatrixRotationAxis(&matX, &VEC3(1.f, 0.f, 0.f), DEGtoRAD(m_pPrt[i].r.x) );
		D3DXMatrixRotationAxis(&matY, &VEC3(0.f, 1.f, 0.f), DEGtoRAD(m_pPrt[i].r.y) );
		D3DXMatrixRotationAxis(&matZ, &VEC3(0.f, 0.f, 1.f), DEGtoRAD(m_pPrt[i].r.z) );
		
		// Scaling
		//D3DXMatrixScaling(&matS, m_pPrt[i].s.x, m_pPrt[i].s.y, m_pPrt[i].s.z);
		
		
		m_pVtx[i*6 + 0] = VtxDUV1( -m_pPrt[i].s.w, +m_pPrt[i].s.w, 0, 0, 0, m_pPrt[i].c);
		m_pVtx[i*6 + 1] = VtxDUV1( +m_pPrt[i].s.w, +m_pPrt[i].s.w, 0, 1, 0, m_pPrt[i].c);
		m_pVtx[i*6 + 2] = VtxDUV1( -m_pPrt[i].s.w, -m_pPrt[i].s.w, 0, 0, 1, m_pPrt[i].c);
		m_pVtx[i*6 + 3] = VtxDUV1( +m_pPrt[i].s.w, -m_pPrt[i].s.w, 0, 1, 1, m_pPrt[i].c);
		
		matW = mtB;// * matS * matX * matY * matZ;
		matW._41 =m_pPrt[i].p.x;
		matW._42 =m_pPrt[i].p.y;
		matW._43 =m_pPrt[i].p.z;
		
		
		D3DXVec3TransformCoord (&(m_pVtx[i*6 + 0].p), &(m_pVtx[i*6 + 0].p), &matW);
		D3DXVec3TransformCoord (&(m_pVtx[i*6 + 1].p), &(m_pVtx[i*6 + 1].p), &matW);
		D3DXVec3TransformCoord (&(m_pVtx[i*6 + 2].p), &(m_pVtx[i*6 + 2].p), &matW);
		D3DXVec3TransformCoord (&(m_pVtx[i*6 + 3].p), &(m_pVtx[i*6 + 3].p), &matW);
		
		m_pVtx[i*6 + 4] = m_pVtx[i*6 + 2];
		m_pVtx[i*6 + 5] = m_pVtx[i*6 + 1];
	}
	
	return 1;
}

void CEftPetal::Render()
{	
	if(!m_bRn)
		return;
	
	GDEVICE->SetRenderState(D3DRS_ZENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);
	
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	GDEVICE->SetFVF(VtxDUV1::FVF);
	GDEVICE->SetTexture(0, m_pTx);
	
	GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iN * 2, m_pVtx, sizeof(VtxDUV1) );
}



void CEftPetal::SetParam_Num(int	iV)
{
	if(iV< 1)
		return;

	m_iN = iV;
	SAFE_FREE(	m_pPrt	);
	SAFE_FREE(	m_pVtx	);
	m_pPrt = (EftPt*) calloc(m_iN, sizeof(EftPt));
	m_pVtx = (VtxDUV1*) calloc(m_iN*6, sizeof(VtxDUV1));

	for(int i=0;i<m_iN; ++i)
	{
		Set(i);
	}
}

void CEftPetal::SetParam_P_X(float	fV)
{
	m_Param.p.x = fV;
}

void CEftPetal::SetParam_P_Y(float	fV)
{
	m_Param.p.y = fV;
}

void CEftPetal::SetParam_P_Z(float	fV)
{
	m_Param.p.z = fV;
}

void CEftPetal::SetParam_V_X(float	fV)
{
	m_Param.v.x = fV;
}

void CEftPetal::SetParam_V_Y(float	fV)
{
	m_Param.v.y = fV;
}

void CEftPetal::SetParam_V_Z(float	fV)
{
	m_Param.v.z = fV;
}

void CEftPetal::SetParam_R_X(float	fV)
{
	m_Param.r.x = fV;
}

void CEftPetal::SetParam_R_Y(float	fV)
{
	m_Param.r.y = fV;
}

void CEftPetal::SetParam_R_Z(float	fV)
{
	m_Param.r.z = fV;
}

void CEftPetal::SetParam_RV_X(float	fV)
{
	m_Param.rV.x = fV;
}

void CEftPetal::SetParam_RV_Y(float	fV)
{
	m_Param.rV.y = fV;
}

void CEftPetal::SetParam_RV_Z(float	fV)
{
	m_Param.rV.z = fV;
}

void CEftPetal::SetParam_S_X(float	fV)
{
	m_Param.s.x = fV;
}

void CEftPetal::SetParam_S_Y(float	fV)
{
	m_Param.s.y = fV;
}

void CEftPetal::SetParam_S_Z(float	fV)
{
	m_Param.s.z = fV;
}

void CEftPetal::SetParam_XCLR_R(float	fV)
{
	m_Param.c.r = fV;
}

void CEftPetal::SetParam_XCLR_G(float	fV)
{
	m_Param.c.g = fV;
}

void CEftPetal::SetParam_XCLR_B(float	fV)
{
	m_Param.c.b = fV;
}

void CEftPetal::SetParam_XCLR_A(float	fV)
{
	m_Param.c.a = fV;
}

void CEftPetal::SetParam_XCLR_C_R(float	fV)
{
	m_Param.cV.r = fV;
}

void CEftPetal::SetParam_XCLR_C_G(float	fV)
{
	m_Param.cV.g = fV;
}

void CEftPetal::SetParam_XCLR_C_B(float	fV)
{
	m_Param.cV.b = fV;
}

void CEftPetal::SetParam_XCLR_C_A(float	fV)
{
	m_Param.cV.a = fV;
}

void CEftPetal::SetParam_WND_X(float	fV)
{
	m_vcWind.x = fV;
	D3DXVec3Normalize(&m_vcWind, &m_vcWind);
}

void CEftPetal::SetParam_WND_Y(float	fV)
{
	m_vcWind.y = fV;
	D3DXVec3Normalize(&m_vcWind, &m_vcWind);
}

void CEftPetal::SetParam_WND_Z(float	fV)
{
	m_vcWind.z = fV;
	D3DXVec3Normalize(&m_vcWind, &m_vcWind);
}

void CEftPetal::SetParam_WND_Length(float	fV)
{
	m_fWindL= fV;
}

void CEftPetal::SetParam_PRT_X(float	fV)
{
	m_vcPrtb.x = fV;
}

void CEftPetal::SetParam_PRT_Y(float	fV)
{
	m_vcPrtb.y = fV;
}

void CEftPetal::SetParam_PRT_Z(float	fV)
{
	m_vcPrtb.z = fV;
}


void CEftPetal::SetParam_Bill(int iV)
{
	m_bBill = iV;
}