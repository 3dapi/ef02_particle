// File: DxMFC.cpp
// Desc: DirectX MFC dialog application created by the DirectX AppWizard

#define STRICT
#include "stdafx.h"


// Application globals

TCHAR*          g_strAppTitle       = _T( "DxMFC" );
CApp            g_App;
HINSTANCE       g_hInst = NULL;
CAppForm*       g_AppFormView = NULL;





// The MFC macros are all listed here

IMPLEMENT_DYNCREATE( CAppDoc,      CDocument )
IMPLEMENT_DYNCREATE( CAppFrameWnd, CFrameWnd )
IMPLEMENT_DYNCREATE( CAppForm,     CFormView )




BEGIN_MESSAGE_MAP( CApp, CWinApp )
//{{AFX_MSG_MAP(CApp)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()




BEGIN_MESSAGE_MAP( CAppForm, CFormView )
//{{AFX_MSG_MAP(CAppForm)
ON_EN_CHANGE(    IDC_PARMA_NUM          , OnParam_num       )
ON_EN_CHANGE(    IDC_PARAM_P_X          , OnParam_p_x       )
ON_EN_CHANGE(    IDC_PARAM_P_Y          , OnParam_p_y       )
ON_EN_CHANGE(    IDC_PARAM_P_Z          , OnParam_p_z       )
ON_EN_CHANGE(    IDC_PARAM_V_X          , OnParam_v_x       )
ON_EN_CHANGE(    IDC_PARAM_V_Y          , OnParam_v_y       )
ON_EN_CHANGE(    IDC_PARAM_V_Z          , OnParam_v_z       )
ON_EN_CHANGE(    IDC_PARAM_R_X          , OnParam_r_x       )
ON_EN_CHANGE(    IDC_PARAM_R_Y          , OnParam_r_y       )
ON_EN_CHANGE(    IDC_PARAM_R_Z          , OnParam_r_z       )
ON_EN_CHANGE(    IDC_PARAM_RV_X         , OnParam_rv_x      )
ON_EN_CHANGE(    IDC_PARAM_RV_Y         , OnParam_rv_y      )
ON_EN_CHANGE(    IDC_PARAM_RV_Z         , OnParam_rv_z      )
ON_EN_CHANGE(    IDC_PARAM_S_X          , OnParam_s_x       )
ON_EN_CHANGE(    IDC_PARAM_S_Y          , OnParam_s_y       )
ON_EN_CHANGE(    IDC_PARAM_S_Z          , OnParam_s_z       )
ON_EN_CHANGE(    IDC_PARAM_XCLR_R       , OnParam_xclr_r    )
ON_EN_CHANGE(    IDC_PARAM_XCLR_G       , OnParam_xclr_g    )
ON_EN_CHANGE(    IDC_PARAM_XCLR_B       , OnParam_xclr_b    )
ON_EN_CHANGE(    IDC_PARAM_XCLR_A       , OnParam_xclr_a    )
ON_EN_CHANGE(    IDC_PARAM_XCLR_C_R     , OnParam_xclr_c_r  )
ON_EN_CHANGE(    IDC_PARAM_XCLR_C_G     , OnParam_xclr_c_g  )
ON_EN_CHANGE(    IDC_PARAM_XCLR_C_B     , OnParam_xclr_c_b  )
ON_EN_CHANGE(    IDC_PARAM_XCLR_C_A     , OnParam_xclr_c_a  )
ON_EN_CHANGE(    IDC_PARAM_WND_X        , OnParam_wnd_x     )
ON_EN_CHANGE(    IDC_PARAM_WND_Y        , OnParam_wnd_y     )
ON_EN_CHANGE(    IDC_PARAM_WND_Z        , OnParam_wnd_z     )
ON_EN_CHANGE(    IDC_PARAM_WND_LENGTH   , OnParam_wnd_length)
ON_EN_CHANGE(    IDC_PARAM_PRT_X        , OnParam_prt_x     )
ON_EN_CHANGE(    IDC_PARAM_PRT_Y        , OnParam_prt_y     )
ON_EN_CHANGE(    IDC_PARAM_PRT_Z        , OnParam_prt_z     )

ON_EN_CHANGE(    IDC_BILLBOARD			, OnParam_Bill     )

ON_COMMAND(    IDC_VIEWFULLSCREEN, OnToggleFullScreen )
ON_BN_CLICKED(IDC_CHANGEDEVICE, OnChangeDevice)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()




BEGIN_MESSAGE_MAP(CAppDoc, CDocument)
//{{AFX_MSG_MAP(CAppDoc)
// NOTE - the ClassWizard will add and remove mapping macros here.
//    DO NOT EDIT what you see in these blocks of generated code!
//}}AFX_MSG_MAP
END_MESSAGE_MAP()




BEGIN_MESSAGE_MAP(CAppFrameWnd, CFrameWnd)
//{{AFX_MSG_MAP(CAppFrameWnd)
ON_COMMAND(IDM_CHANGEDEVICE, OnChangeDevice)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()



CAppForm::CAppForm()
:CFormView( IDD_FORMVIEW )
{
	//{{AFX_DATA_INIT(CAppForm)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	g_AppFormView          = this;
	m_hwndRenderWindow     = NULL;
	m_hwndRenderFullScreen = NULL;
	m_hWndTopLevelParent   = NULL;

	m_strWindowTitle            = TEXT( "DxMFC" );

	m_bLoadingApp               = TRUE;
	m_pMain						= NULL;
}





HRESULT CAppForm::OneTimeSceneInit()
{
	// TODO: perform one time initialization

	m_bLoadingApp = FALSE;

	return S_OK;
}



HRESULT CAppForm::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
								D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( pCaps );
	UNREFERENCED_PARAMETER( dwBehavior );
	UNREFERENCED_PARAMETER( Format );
	BOOL bCapsAcceptable;

	// TODO: Perform checks to see if these display caps are acceptable.
	bCapsAcceptable = TRUE;

	if( bCapsAcceptable )
		return S_OK;
	else
		return E_FAIL;
}

HRESULT CAppForm::InitDeviceObjects()
{
	BOOL hr=	this->SetWindowPos(this, 1, 1, 0, 0, TRUE);

	SAFE_NEWINIT(m_pMain,	CMain);

	return S_OK;
}



HRESULT CAppForm::RestoreDeviceObjects()
{
	SAFE_RESTORE(	m_pMain	);
	return S_OK;
}



HRESULT CAppForm::FrameMove()
{
	SAFE_FRMOV(	m_pMain	);

	return S_OK;
}


HRESULT CAppForm::Render()
{
	SAFE_RENDER(	m_pMain	);

	return S_OK;
}


// Name: DoDataExchange()
// Desc: DDX/DDV support

void CAppForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAppForm)
	//}}AFX_DATA_MAP
}



LRESULT CAppForm::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	return CFormView ::WindowProc(message, wParam, lParam);
}




void CAppFrameWnd::OnChangeDevice()
{
	g_AppFormView->OnChangeDevice();
}


HRESULT CAppForm::InvalidateDeviceObjects()
{
	SAFE_INVALID(	m_pMain	);

	return S_OK;
}



HRESULT CAppForm::DeleteDeviceObjects()
{
	if(m_pMain)
		m_pMain->Destroy();

	SAFE_DELETE(	m_pMain	);
	return S_OK;
}



HRESULT CAppForm::FinalCleanup()
{
	// TODO: Perform any final cleanup needed
	return S_OK;
}




BOOL CApp::InitInstance()
{
	// Asscociate the MFC app with the frame window and doc/view classes
	AddDocTemplate( new CSingleDocTemplate( IDR_MAINFRAME,
		RUNTIME_CLASS(CAppDoc),
		RUNTIME_CLASS(CAppFrameWnd),
		RUNTIME_CLASS(CAppForm) ) );

	// Dispatch commands specified on the command line (req'd by MFC). This
	// also initializes the the CAppDoc, CAppFrameWnd, and CAppForm classes.
	CCommandLineInfo cmdInfo;
	ParseCommandLine( cmdInfo );
	if( !ProcessShellCommand( cmdInfo ) )
		return FALSE;

	if( !g_AppFormView->IsReady() )
		return FALSE;

	g_AppFormView->GetParentFrame()->RecalcLayout();
	g_AppFormView->ResizeParentToFit( FALSE );

	m_pMainWnd->SetWindowText( g_strAppTitle );
	m_pMainWnd->UpdateWindow();

	return TRUE;
}




// Name: LoadFrame()
// Desc: Uses idle time to render the 3D scene.

BOOL CAppFrameWnd::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext)
{
	BOOL bResult = CFrameWnd::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext);

	// Remove the menu bar.  Do it this way because CFrameWnd::LoadFrame() requires
	// there be a menu called IDR_MAINFRAME.
	SetMenu( NULL );

	LoadAccelTable( MAKEINTRESOURCE(IDR_MAIN_ACCEL) );

	return bResult;
}




// Name: OnIdle()
// Desc: Uses idle time to render the 3D scene.

BOOL CApp::OnIdle( LONG )
{
	// Do not render if the app is minimized
	if( m_pMainWnd->IsIconic() )
		return FALSE;

	TCHAR strStatsPrev[200];

	lstrcpy(strStatsPrev, g_AppFormView->PstrFrameStats());

	// Update and render a frame
	if( g_AppFormView->IsReady() )
	{
		g_AppFormView->CheckForLostFullscreen();
		g_AppFormView->RenderScene();
	}

	// Keep requesting more idle time
	return TRUE;
}




// Name: PreCreateWindow()
// Desc: Change the window style (so it cannot maximize or be sized) before
//       the main frame window is created.

BOOL CAppFrameWnd::PreCreateWindow( CREATESTRUCT& cs )
{
	cs.style = WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU;

	cs.x = 10;
	cs.y = 50;

	return CFrameWnd::PreCreateWindow( cs );
}




// Name: ~CAppForm()
// Desc: Destructor for the dialog resource form. Shuts down the app

CAppForm::~CAppForm()
{
	Cleanup3DEnvironment();
	SAFE_RELEASE( m_pD3D );
	FinalCleanup();
}




// Name: OnToggleFullScreen()
// Desc: Called when user toggles the fullscreen mode

void CAppForm::OnToggleFullScreen()
{
	ToggleFullscreen();
}




// Name: OnChangeDevice()
// Desc: Use hit the "Change Device.." button. Display the dialog for the user
//       to select a new device/mode, and call Change3DEnvironment to
//       use the new device/mode.

VOID CAppForm::OnChangeDevice()
{
	Pause(true);

	UserSelectNewDevice();

	// Update UI
	UpdateUIForDeviceCapabilites();

	Pause(false);
}




// Name: AdjustWindowForChange()
// Desc: Adjusts the window properties for windowed or fullscreen mode

HRESULT CAppForm::AdjustWindowForChange()
{
	if( m_bWindowed )
	{
		::ShowWindow( m_hwndRenderFullScreen, SW_HIDE );
		CD3DApplication::m_hWnd = m_hwndRenderWindow;
	}
	else
	{
		if( ::IsIconic( m_hwndRenderFullScreen ) )
			::ShowWindow( m_hwndRenderFullScreen, SW_RESTORE );
		::ShowWindow( m_hwndRenderFullScreen, SW_SHOW );
		CD3DApplication::m_hWnd = m_hwndRenderFullScreen;
	}

	return S_OK;
}




// Name: FullScreenWndProc()
// Desc: The WndProc funtion used when the app is in fullscreen mode. This is
//       needed simply to trap the ESC key.

LRESULT CALLBACK FullScreenWndProc( HWND hWnd, UINT msg, WPARAM wParam,
								   LPARAM lParam )
{
	if( msg == WM_CLOSE )
	{
		// User wants to exit, so go back to windowed mode and exit for real
		g_AppFormView->OnToggleFullScreen();
		g_App.GetMainWnd()->PostMessage( WM_CLOSE, 0, 0 );
	}
	else if( msg == WM_SETCURSOR )
	{
		SetCursor( NULL );
	}
	else if( msg == WM_KEYUP && wParam == VK_ESCAPE )
	{
		// User wants to leave fullscreen mode
		g_AppFormView->OnToggleFullScreen();
	}

	return DefWindowProc( hWnd, msg, wParam, lParam );
}




// Name: CheckForLostFullscreen()
// Desc: If fullscreen and device was lost (probably due to alt-tab),
//       automatically switch to windowed mode

HRESULT CAppForm::CheckForLostFullscreen()
{
	HRESULT hr;

	if( m_bWindowed )
		return S_OK;

	if( FAILED( hr = m_pd3dDevice->TestCooperativeLevel() ) )
		ForceWindowed();

	return S_OK;
}




// Name: UpdateUIForDeviceCapabilites()
// Desc: Whenever we get a new device, call this function to enable/disable the
//       appropiate UI controls to match the device's capabilities.

VOID CAppForm::UpdateUIForDeviceCapabilites()
{
	// TODO: Check the capabilities of the device and update the UI as needed
	DWORD dwCaps = m_d3dCaps.RasterCaps;
	UNREFERENCED_PARAMETER( dwCaps );
}




// Name: OnInitialUpdate()
// Desc: When the AppForm object is created, this function is called to
//       initialize it. Here we getting access ptrs to some of the controls,
//       and setting the initial state of some of them as well.

VOID CAppForm::OnInitialUpdate()
{
	// Update the UI
	CFormView::OnInitialUpdate();

	// Get the top level parent hwnd
	m_hWndTopLevelParent = GetTopLevelParent()->GetSafeHwnd();

	// Save static reference to the render window
	m_hwndRenderWindow = GetDlgItem(IDC_RENDERVIEW)->GetSafeHwnd();

	// Register a class for a fullscreen window
	WNDCLASS wndClass = { CS_HREDRAW | CS_VREDRAW, FullScreenWndProc, 0, 0, NULL,
		NULL, NULL, (HBRUSH)GetStockObject(WHITE_BRUSH), NULL,
		_T("Fullscreen Window") };
	RegisterClass( &wndClass );

	// We create the fullscreen window (not visible) at startup, so it can
	// be the focus window.  The focus window can only be set at CreateDevice
	// time, not in a Reset, so ToggleFullscreen wouldn't work unless we have
	// already set up the fullscreen focus window.
	m_hwndRenderFullScreen = CreateWindow( _T("Fullscreen Window"), NULL,
		WS_POPUP, CW_USEDEFAULT,
		CW_USEDEFAULT, 0, 0,
		m_hWndTopLevelParent, 0L, NULL, 0L );

	// Note that for the MFC samples, the device window and focus window
	// are not the same.
	CD3DApplication::m_hWnd = m_hwndRenderWindow;
	CD3DApplication::m_hWndFocus = m_hwndRenderFullScreen;
	CD3DApplication::Create( AfxGetInstanceHandle() );

	// TODO: Update the UI as needed
}



VOID CAppForm::OnParam_num()
{
	CString str;
	GetDlgItem(IDC_PARMA_NUM        )->GetWindowText(str);

	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_Num(atoi(p));
}

VOID CAppForm::OnParam_p_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_P_X        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_P_X(atof(p));
}

VOID CAppForm::OnParam_p_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_P_Y        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_P_Y(atof(p));
}

VOID CAppForm::OnParam_p_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_P_Z        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_P_Z(atof(p));
}

VOID CAppForm::OnParam_v_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_V_X        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_V_X(atof(p));
}

VOID CAppForm::OnParam_v_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_V_Y        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_V_Y(atof(p));
}

VOID CAppForm::OnParam_v_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_V_Z        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_V_Z(atof(p));
}

VOID CAppForm::OnParam_r_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_R_X        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_R_X(atof(p));
}

VOID CAppForm::OnParam_r_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_R_Y        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_R_Y(atof(p));
}

VOID CAppForm::OnParam_r_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_R_Z        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_R_Z(atof(p));
}

VOID CAppForm::OnParam_rv_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_RV_X       )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_RV_X(atof(p));
}

VOID CAppForm::OnParam_rv_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_RV_Y       )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_RV_Y(atof(p));
}

VOID CAppForm::OnParam_rv_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_RV_Z       )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_RV_Z(atof(p));
}

VOID CAppForm::OnParam_s_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_S_X        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_S_X(atof(p));
}

VOID CAppForm::OnParam_s_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_S_Y        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_S_Y(atof(p));
}

VOID CAppForm::OnParam_s_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_S_Z        )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_S_Z(atof(p));
}

VOID CAppForm::OnParam_xclr_r()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_R     )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_R(atof(p));
}

VOID CAppForm::OnParam_xclr_g()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_G     )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_G(atof(p));
}

VOID CAppForm::OnParam_xclr_b()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_B     )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_B(atof(p));
}

VOID CAppForm::OnParam_xclr_a()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_A     )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_A(atof(p));
}

VOID CAppForm::OnParam_xclr_c_r()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_C_R   )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_C_R(atof(p));
}

VOID CAppForm::OnParam_xclr_c_g()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_C_G   )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_C_G(atof(p));
}

VOID CAppForm::OnParam_xclr_c_b()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_C_B   )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_C_B(atof(p));
}

VOID CAppForm::OnParam_xclr_c_a()
{
	CString str;
	GetDlgItem(IDC_PARAM_XCLR_C_A   )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_XCLR_C_A(atof(p));
}

VOID CAppForm::OnParam_wnd_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_WND_X      )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_WND_X(atof(p));
}

VOID CAppForm::OnParam_wnd_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_WND_Y      )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_WND_Y(atof(p));
}

VOID CAppForm::OnParam_wnd_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_WND_Z      )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_WND_Z(atof(p));
}

VOID CAppForm::OnParam_wnd_length()
{
	CString str;
	GetDlgItem(IDC_PARAM_WND_LENGTH )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_WND_Length(atof(p));
}

VOID CAppForm::OnParam_prt_x()
{
	CString str;
	GetDlgItem(IDC_PARAM_PRT_X      )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_PRT_X(atof(p));
}

VOID CAppForm::OnParam_prt_y()
{
	CString str;
	GetDlgItem(IDC_PARAM_PRT_Y      )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_PRT_Y(atof(p));
}

VOID CAppForm::OnParam_prt_z()
{
	CString str;
	GetDlgItem(IDC_PARAM_PRT_Z      )->GetWindowText(str);
	LPSTR p = str.GetBuffer(str.GetLength());
	GMAIN->m_pScene->m_pEft->SetParam_PRT_Z(atof(p));
}



VOID CAppForm::OnParam_Bill()
{
	int bCheck = ((CButton*)GetDlgItem(IDC_BILLBOARD))->GetCheck();
	GMAIN->m_pScene->m_pEft->SetParam_PRT_Z(bCheck);
}