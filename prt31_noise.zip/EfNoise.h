// Interface for the CEfNoise class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFNOISE_H_
#define _EFNOISE_H_

class CEfNoise
{
public:
	struct VtxwPnt
	{
		D3DXVECTOR4	p;
		DWORD		d;

		VtxwPnt()	{}
		VtxwPnt(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0XFFFFFFFF) : p(X,Y,Z, 1.f),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE) };
	};


protected:
	LPDIRECT3DDEVICE9		m_pDev;
	INT						m_iN;			// Particle Number
	LPDIRECT3DVERTEXBUFFER9	m_pVB;
	LPDIRECT3DTEXTURE9		m_pTx;

	INT						m_ScnW;			// screen width
	INT						m_ScnH;			// screen height

public:
	CEfNoise();
	~CEfNoise();

	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif

