// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pNoise		= NULL;
}


CMain::~CMain()
{
}


HRESULT CMain::InitDeviceObjects()
{
	INT		iParticle = 20000;

	m_pNoise = new CEfNoise;
	if(FAILED(m_pNoise->Create(m_pd3dDevice, &iParticle)))
		return -1;


	return S_OK;
}



HRESULT CMain::RestoreDeviceObjects()
{
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	sprintf(m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	m_pNoise->FrameMove();
	
	return S_OK;
}


HRESULT CMain::Render()
{
	if(m_bLoadingRnd)
		return 0;

	if(!m_pd3dDevice)
		return -1;
	
	m_pd3dDevice->Clear( 0L, 0, m_dwClr, 0x00006688, 1.0f, 0L );
	
	// Begin the scene
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;
		
	m_pNoise->Render();
	
	RenderText();
	
	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	return S_OK;
}




HRESULT CMain::InvalidateDeviceObjects()
{
	return S_OK;
}


HRESULT CMain::DeleteDeviceObjects()
{
	SAFE_DELETE(	m_pNoise	);

	return S_OK;
}
