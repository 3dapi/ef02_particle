// Implementation of the CEfNoise class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "EfNoise.h"

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }



CEfNoise::CEfNoise()
{
	m_pDev	= NULL;
	m_iN	= 0;
	m_pVB	= 0;
	m_pTx	= 0;
}

CEfNoise::~CEfNoise()
{
	Destroy();
}


INT CEfNoise::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	m_iN	= *((INT*)p2);


	D3DDEVICE_CREATION_PARAMETERS pp={0};
	RECT rc={0};
	m_pDev->GetCreationParameters(&pp);
	GetClientRect(pp.hFocusWindow, &rc);

	m_ScnW = rc.right - rc.left;
	m_ScnH = rc.bottom- rc.top;


	if(FAILED( m_pDev->CreateVertexBuffer( m_iN * sizeof(VtxwPnt)
										, D3DUSAGE_POINTS
										, VtxwPnt::FVF
										, D3DPOOL_MANAGED, &m_pVB
										, 0)))
		return -1;

    VtxwPnt* pVtx;

	if(FAILED(m_pVB->Lock( 0, 0, (void **) &pVtx, 0)))
		return -1;

	for(INT i=0; i<m_iN; ++i)
	{
		pVtx[i].d	= D3DXCOLOR( 1,1,1,1);
		pVtx[i].p.z	= 0.f;
		pVtx[i].p.w	= 1.f;
	}

	m_pVB->Unlock();


	D3DXCreateTextureFromFile(	m_pDev, "Image/particle.png",	&m_pTx);


	return 0;
}


void CEfNoise::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
	SAFE_RELEASE(	m_pTx	);
}



INT CEfNoise::FrameMove()
{
	D3DDEVICE_CREATION_PARAMETERS pp={0};
	RECT rc={0};
	m_pDev->GetCreationParameters(&pp);
	GetClientRect(pp.hFocusWindow, &rc);

	m_ScnW = rc.right - rc.left;
	m_ScnH = rc.bottom- rc.top;

	VtxwPnt* pVtx = NULL;

	if(FAILED(m_pVB->Lock( 0, 0, (void **) &pVtx, 0)))
		return -1;

	for(int i=0; i<m_iN; ++i)
	{
		DWORD d = 200;
		FLOAT x = FLOAT(rand()%m_ScnW);
		FLOAT y = FLOAT(rand()%m_ScnH);

		pVtx[i].d = D3DCOLOR_XRGB(d, d, d);
		pVtx[i].p.x = x;
		pVtx[i].p.y = y;


	}

	m_pVB->Unlock();



	return 0;
}


inline DWORD F2DW( FLOAT f )	{ return *((DWORD*)&f); }


void CEfNoise::Render()
{
	m_pDev->Clear( 0L, 0, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER, 0xFF000000, 1.0f, 0L );

	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );

	m_pDev->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	m_pDev->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	m_pDev->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );

	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, FALSE );

	m_pDev->SetRenderState( D3DRS_POINTSPRITEENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_POINTSCALEENABLE,  TRUE );
	m_pDev->SetRenderState( D3DRS_POINTSIZE,     F2DW(3.f) );
	m_pDev->SetRenderState( D3DRS_POINTSIZE_MIN, F2DW(3.f) );
	m_pDev->SetRenderState( D3DRS_POINTSCALE_A,  F2DW(3.f) );
	m_pDev->SetRenderState( D3DRS_POINTSCALE_B,  F2DW(3.f) );
	m_pDev->SetRenderState( D3DRS_POINTSCALE_C,  F2DW(3.f) );

	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_ONE );
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCCOLOR );
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );


	m_pDev->SetStreamSource( 0, m_pVB, 0, sizeof(VtxwPnt) );
    m_pDev->SetFVF( VtxwPnt::FVF );
	m_pDev->DrawPrimitive(D3DPT_POINTLIST, 0, m_iN);
	m_pDev->SetRenderState( D3DRS_POINTSPRITEENABLE, FALSE );
	m_pDev->SetRenderState( D3DRS_POINTSCALEENABLE,  FALSE );
}