// Program start.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

CMain*				g_pApp	= NULL		;


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR lpCmdLine, INT )
{
	TCHAR	sExe1[512];
	TCHAR	sExe2[512];

	memset(sExe1, 0, sizeof(sExe1));
	memset(sExe2, 0, sizeof(sExe2));

	strcpy(sExe1, GetCommandLine());

	INT	iLen = strlen(sExe1);

	int k=0;

	for(INT i=0; i<iLen; ++i)
	{
		if('"' == sExe1[i])
		{
			++k;
			continue;
		}

		if(2==k)
			break;

		sExe2[i-k] = sExe1[i];
		if('\\' == sExe2[i-k])
			sExe2[i-k] ='/';
	}

	char* pdest;
	
	pdest = (char*)strrchr(sExe2, '/');

	int result;
	result = pdest - sExe2;

	sExe2[result] =0;

	BOOL hr = SetCurrentDirectory(sExe2);


    CMain	d3dApp;
    g_pApp  = &d3dApp;

    InitCommonControls();

    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;
	
    return d3dApp.Run();
}






HRESULT CMain::ConfirmDevice(D3DCAPS9* pCaps,DWORD dwBehavior,D3DFORMAT Format)
{
	UNREFERENCED_PARAMETER( Format );
	UNREFERENCED_PARAMETER( dwBehavior );
	UNREFERENCED_PARAMETER( pCaps );
	
	BOOL bCapsAcceptable;
	
	// TODO: Perform checks to see if these display caps are acceptable.
	bCapsAcceptable = TRUE;
	
	if( bCapsAcceptable )         
		return S_OK;

	return E_FAIL;
}


HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = FALSE;
	
	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		
		
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				RECT rct;
				GetClientRect( hWnd, &rct );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




HRESULT CMain::FinalCleanup()
{
#if EXC_MTX_ON
	if(g_hMtx)
	{
		CloseHandle(g_hMtx);
		g_hMtx	= 0;
	}
	
#endif
	

	return S_OK;
}