// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	TCHAR				m_sMsg[512]	;
	CEfNoise*			m_pNoise	;

public:
	
public:
	CMain();
	virtual ~CMain();
	virtual HRESULT		OneTimeSceneInit();
	virtual HRESULT		InitDeviceObjects();
	virtual HRESULT		RestoreDeviceObjects();
	virtual HRESULT		InvalidateDeviceObjects();
	virtual HRESULT		DeleteDeviceObjects();
	virtual HRESULT		Render();
	virtual HRESULT		FrameMove();
	virtual HRESULT		FinalCleanup();
	virtual HRESULT		ConfirmDevice(D3DCAPS9*,DWORD,D3DFORMAT);
	
	HRESULT				RenderText();
	LRESULT				MsgProc(HWND, UINT, WPARAM, LPARAM);
};

#define GMAIN				g_pApp
extern	CMain*				g_pApp	;												// Main application

#endif

