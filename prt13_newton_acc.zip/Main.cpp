// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	strcpy(m_strClassName, TEXT( "Mck" ));

	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pInput	= NULL;
	m_pGrid		= NULL;
	m_pCam		= NULL;
	m_pD3DXFont	= NULL;

	m_pPrt		= NULL;
}



HRESULT CMain::Init()
{
	HRESULT hr=-1;

	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE, "Arial"
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;


	// Input ����
	m_pInput = new CMcInput;
	m_pInput->Create(m_hWnd);

	// Grid����
	m_pGrid = new CMcGrid;
	m_pGrid->Create(m_pd3dDevice);

	// ī�޶� ����
	m_pCam = new CMcCam;
	m_pCam->Create(m_pd3dDevice);

	m_pPrt = new CMcParticle;
	m_pPrt->Create(m_pd3dDevice);

	return S_OK;
}



HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);

	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pInput	);

	SAFE_DELETE(	m_pPrt		);
	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L );

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	m_pInput->FrameMove();

	// Wheel mouse...
	D3DXVECTOR3 vcD = m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
		m_pCam->MoveForward(-vcD.z* 1.f, 1.f);

	if(m_pInput->KeyState('W'))					// W
		m_pCam->MoveForward( 4.f, 1.f);

	if(m_pInput->KeyState('S'))					// S
		m_pCam->MoveForward(-4.f, 1.f);

	if(m_pInput->KeyState('A'))					// A
		m_pCam->MoveSide(-4.f);

	if(m_pInput->KeyState('D'))					// D
		m_pCam->MoveSide(4.f);


	if(m_pInput->BtnPress(1))
	{
		D3DXVECTOR3 vcDelta = m_pInput->GetMouseEps();
		m_pCam->Rotation(vcDelta);
	}

	m_pCam->FrameMove();


	if(m_pInput->KeyDown('R'))
	{
		m_pPrt->SetAni();
		m_pPrt->SetAvgTime(1000.f/m_fFPS);
	}


	m_pPrt->FrameMove();

	return S_OK;
}




HRESULT CMain::Render()
{
	

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	// ī�޶� Ŭ������ �Լ� ȣ��
	m_pCam->SetTransform();

	//�׸��带 �׸���.
	m_pGrid->Render();

	// ��ƼŬ�� �׸���.
	m_pPrt->Render();

	RenderText();

	// End the scene.
	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= {0};

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	RECT rc={ 10, 10, m_d3dsdBackBuffer.Width - 20, 10+30};
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, fontColor );

	rc.top	 +=50;
	rc.bottom+=50;
	m_pD3DXFont->DrawText(NULL, "Press \'R\' Key", -1, &rc, 0, fontColor );


	return S_OK;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);


	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, hDC );
			}

			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}


