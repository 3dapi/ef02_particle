// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
protected:
	CMcInput*		m_pInput	;
	CMcCam*			m_pCam		;
	CMcGrid*		m_pGrid		;
	ID3DXFont*      m_pD3DXFont	;           // D3DX font
	CMcParticle*	m_pPrt		;

public:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

    HRESULT RenderText();

public:
	CMain();
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
};


extern CMain* g_pApp;

#endif



