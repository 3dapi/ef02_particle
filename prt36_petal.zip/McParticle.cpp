// Implementation of the CMcParticle class.
//
////////////////////////////////////////////////////////////////////////////////
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

#include <Windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "McParticle.h"


inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }

// Texture Load
INT	McUtil_TextureLoad(	LPDIRECT3DDEVICE9	pDev
					,	LPDIRECT3DTEXTURE9& texture
					,	TCHAR* sFileName
					,	DWORD _color=0xffffffff
					,	D3DXIMAGE_INFO *pSrcInfo=NULL
					,	DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
					,	DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
					,	D3DFORMAT d3dFormat = D3DFMT_UNKNOWN
					   )
{
	if ( FAILED(D3DXCreateTextureFromFileEx(
		pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat	//, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)) )
	{
		texture = NULL;
		return -1;
	}
	
	return 1;
}

CMcParticle::CMcParticle()
{
	m_pDev		= NULL;

	m_PrtN		= 0;
	m_PrtD		= NULL;

	m_fTimeAvg	= 0;
	m_bAni		= FALSE;
	
	m_pVtx		= NULL;
	m_pTx		= NULL;
}

CMcParticle::~CMcParticle()
{
	Destroy();
}


INT CMcParticle::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	m_PrtN	= 1000;
	m_PrtD	= new CMcParticle::Tpart[m_PrtN];
	

	// ������ � ��¿� ����
	m_iVtx	= m_PrtN * 2 * 3;
	m_pVtx	= new VtxDUV1[ m_iVtx ];
	

	McUtil_TextureLoad(m_pDev, m_pTx, "Texture/Petal.png", 0x00FFFFFF);

	return 0;
}


void CMcParticle::Destroy()
{
	SAFE_DELETE_ARRAY(	m_PrtD	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_RELEASE(		m_pTx	);
}

INT CMcParticle::FrameMove()
{
	if(!m_bAni)
		return 0;

	INT i;

	float fWindL = 2.f;
	m_vcWind = D3DXVECTOR3(1.f, 0, 1.f) * fWindL;

	
	D3DXMATRIX matX;
	D3DXMATRIX matY;
	D3DXMATRIX matZ;
	D3DXMATRIX matS;
	D3DXMATRIX matW;

	D3DXVECTOR3 vcWind;


	// 1. ��� �����Ѵ�.
	FLOAT	ftime = m_fTimeAvg * 0.1f;


	for(i=0; i<m_PrtN; ++i)
	{
		CMcParticle::Tpart* pPrt = &m_PrtD[i];


		// ���������� ���Ѵ�.
		D3DXVECTOR3	vcAirR = pPrt->CrnV;					// ���������� ���� ����
		FLOAT		fLenV  = D3DXVec3LengthSq(&vcAirR);		// �ӵ��� ����(Vx*Vx + Vy*Vy + Vz*Vz)ũ�� ����

		// ���������� ���� ���͸� ���Ѵ�.
		D3DXVec3Normalize(&vcAirR, &vcAirR);

		// �̵� �ӵ��� �ݴ�� ����
		vcAirR	*= -1.F;

		// �ӷ����� * ���� ���� ����� ����.
		vcAirR	*= fLenV * pPrt->fDamp;


		// �ٶ��� ���� perturbation�� ���Ѵ�.
		vcWind.x = m_vcWind.x * (10 + rand()%11)/20.f * (1+sinf(D3DXToRadian(pPrt->CrnR.x)));
		vcWind.y = m_vcWind.y * (10 + rand()%11)/20.f * (1+sinf(D3DXToRadian(pPrt->CrnR.y)));
		vcWind.z = m_vcWind.z * (10 + rand()%11)/20.f * (1+sinf(D3DXToRadian(pPrt->CrnR.z)));

		// ȸ�� ��Ҹ� ÷�� �Ѵ�.
		vcWind.x += 1.8F* sinf(D3DXToRadian(pPrt->CrnR.x));
		vcWind.y += 1.8F* sinf(D3DXToRadian(pPrt->CrnR.y));
		vcWind.z += 1.8F* sinf(D3DXToRadian(pPrt->CrnR.z));

		vcWind *=.8F;

		// 1. ���ӵ��� ���������� ���Ѵ�.
		pPrt->CrnA = pPrt->IntA + vcAirR;

		// 2. ���� �ӵ� ����
		pPrt->CrnV += pPrt->CrnA * ftime;

		// 3. ���� ��ġ ����
		pPrt->CrnP += pPrt->CrnV * ftime;
		pPrt->CrnP += vcWind * ftime;

		// ȸ��
		pPrt->CrnR +=pPrt->CrnRv * ftime;


		// 4. ���� ��ƼŬ�� ����Ѵ�.
		if(pPrt->CrnP.y<0.f)
		{
			this->SetPart(i);
		}
	}



	// 4. ����� �����Ѵ�.

	// ī�޶��� ����
	D3DXMATRIX mtView;
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	D3DXVECTOR3 vcCamX(mtView._11, mtView._21, mtView._31);
	D3DXVECTOR3 vcCamY(mtView._12, mtView._22, mtView._32);
	D3DXVECTOR3 vcCamZ(mtView._13, mtView._23, mtView._33);

	for(i=0; i<m_PrtN; ++i)
	{	
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		D3DXVECTOR3	vcP	= pPrt->CrnP;

		// ī�޶��� Z��� ��ƼŬ�� ��ġ�� ����
		pPrt->PrsZ	= D3DXVec3Dot(&vcP, &vcCamZ);
	}

	// Sorting
	qsort (m_PrtD
			, m_PrtN
			, sizeof(CMcParticle::Tpart)
			, (int(*) (const void *, const void *)) CMcParticle::SortFnc);


	for(i=0; i<m_PrtN; ++i)
	{	
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		D3DXVECTOR3	vcP	= pPrt->CrnP;
		D3DXCOLOR	xcC	= pPrt->dColor;

		FLOAT		fW = pPrt->PrsW;
		FLOAT		fH = pPrt->PrsH;
		FLOAT		fD = min(fW, fH);

		CMcParticle::VtxDUV1* pVtx = &m_pVtx[i*6 + 0];


		// Rotation		
		D3DXMatrixRotationAxis(&matX, &D3DXVECTOR3(1.f,0.f,0.f),D3DXToRadian(pPrt->CrnR.x));
		D3DXMatrixRotationAxis(&matY, &D3DXVECTOR3(0.f,1.f,0.f),D3DXToRadian(pPrt->CrnR.y));
		D3DXMatrixRotationAxis(&matZ, &D3DXVECTOR3(0.f,0.f,1.f),D3DXToRadian(pPrt->CrnR.z));

		// Scaling
		D3DXMatrixScaling( &matS, pPrt->CrnS.x, pPrt->CrnS.y, pPrt->CrnS.z);

		// World matrix setup
		matW = matS * matX * matY * matZ;
		matW._41 =pPrt->CrnP.x;
		matW._42 =pPrt->CrnP.y;
		matW._43 =pPrt->CrnP.z;


		// vertex setup
		m_pVtx[i*6 + 0] = VtxDUV1( -fW, +fH, 0, 0, 0, xcC);
		m_pVtx[i*6 + 1] = VtxDUV1( +fW, +fH, 0, 1, 0, xcC);
		m_pVtx[i*6 + 2] = VtxDUV1( -fW, -fH, 0, 0, 1, xcC);
		m_pVtx[i*6 + 3] = VtxDUV1( +fW, -fH, 0, 1, 1, xcC);

		D3DXVec3TransformCoord( &(pVtx+0)->p, &(pVtx+0)->p, &matW);
		D3DXVec3TransformCoord( &(pVtx+1)->p, &(pVtx+1)->p, &matW);
		D3DXVec3TransformCoord( &(pVtx+2)->p, &(pVtx+2)->p, &matW);
		D3DXVec3TransformCoord( &(pVtx+3)->p, &(pVtx+3)->p, &matW);
		
		m_pVtx[i*6 + 4] = m_pVtx[i*6 + 2];
		m_pVtx[i*6 + 5] = m_pVtx[i*6 + 1];
	}


	return 0;
}

void CMcParticle::Render()
{
	if(!m_bAni)
		return;

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetFVF(VtxDUV1::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_PrtN * 2, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);

	m_pDev->SetTexture(0, NULL);

	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}


void CMcParticle::SetAni(BOOL bAni)
{
	m_bAni = bAni;

	if(!m_bAni)
		return;

	for(int i=0; i<m_PrtN; ++i)
	{
		SetPart(i);
	}
}


void CMcParticle::SetAvgTime(FLOAT fTime)
{
	m_fTimeAvg = fTime;
}





void CMcParticle::SetPart(int nIdx)
{
	CMcParticle::Tpart* pPrt = &m_PrtD[nIdx];

	// �ʱ� ���ӵ�
	pPrt->IntA = D3DXVECTOR3(0, -0.003F, 0);

	// �ʱ� �ӵ�
	pPrt->IntV.x	= rand()%10 /10.f *5.f;
	pPrt->IntV.y	=-rand()%10 /10.f *5.f;
	pPrt->IntV.z	= rand()%10 /10.f *5.f;

	pPrt->IntV	*=0.1F;

	// �ʱ� ��ġ		
	pPrt->IntP.x	= 1000.f - rand()%2000;
	pPrt->IntP.y	=   10.f + rand()%400;
	pPrt->IntP.z	= 1000.f - rand()%2000;

	// �ʱ� ȸ��
	pPrt->CrnR.x	= 0.f + rand()%360;
	pPrt->CrnR.y	= 0.f + rand()%360;
	pPrt->CrnR.z	= 0.f + rand()%360;

	// ȸ�� �ӵ�
	pPrt->CrnRv.x	=(rand()%91-45.5f) *1.2f;
	pPrt->CrnRv.y	=(rand()%91-45.5f) *1.2f;
	pPrt->CrnRv.z	=(rand()%91-45.5f) *1.2f;

	pPrt->CrnRv	*=0.1F;

	// �ʱ� ������
	pPrt->CrnS.x	= ( 5 + rand()%101) /50.f;
	pPrt->CrnS.y	= (10 + rand()%101) /50.f;
	pPrt->CrnS.z	= ( 5 + rand()%101) /50.f;


	// ź�� ��� ����
	pPrt->fElst= 1.0f;

	// �������� ���
	pPrt->fDamp= (100 + rand()%101)*0.00001F;


	// �ʱ� ��ġ, �ӵ�, ���ӵ��� ������ ������ �ʱ� ������ ����
	pPrt->CrnP = pPrt->IntP;
	pPrt->CrnV = pPrt->IntV;
	pPrt->CrnA = pPrt->IntA;



	// ������ ���� ���
	pPrt->bLive	= TRUE;
	pPrt->fLife	= 30.f + rand()%71;
	pPrt->fLife	= 30.f + rand()%71;
	pPrt->fLife	*=0.01f;

	pPrt->fFade	=( 100 + rand()%101  ) *0.0001f;
	
	D3DXCOLOR	dColor = D3DXCOLOR(0.85f, 0.85f, 0.85f, 1.f);
	dColor.r += (rand()%16)/15.f;
	dColor.g += (rand()%16)/15.f;
	dColor.b += (rand()%16)/15.f;
	pPrt->dColor =	dColor;
	


	// ������ ǥ�� ���
	pPrt->PrsW = 50.f + rand()%101;
	pPrt->PrsW *= 0.05f;

	pPrt->PrsH = 50.f + rand()%101;
	pPrt->PrsH *= 0.1f;

//	pPrt->PrsW = 1.6f;
//	pPrt->PrsH = 3.2f;
}


